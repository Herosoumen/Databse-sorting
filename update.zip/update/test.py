from flask import Flask, render_template, flash, request
from flaskext.mysql import MySQL
from flask_sqlalchemy import SQLAlchemy
import pymysql
pymysql.install_as_MySQLdb()


app = Flask(__name__)

mysql = MySQL()


app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/soumen95'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.secret_key = 'qwertyuioplkjhgfdsazxcvbnn'

db = SQLAlchemy(app)
mysql.init_app(app)


class Sortable(db.Model):
	__tablename__ = 'sortable'
	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String)
	pref = db.Column(db.Integer)



@app.route("/")
def home():
	data = Sortable.query.filter().all()
	return render_template('index.html',data = data)


@app.route('/post', methods=['GET', 'POST'])
def post():
    json = request.json
    print(json)
    x = json.replace('item[]=', ',')
    print("x",x)
    y = x.replace('&,', '')
    print("y",y)
    final = y.replace(',', '')
    print(type(final))
    # for i in range(final):
    # 	new_data = Sortable.query.filter_by(id = 1 ).first()
    # 	new_data.pref = final[2]
    # 	db.session.commit()
    new_data = Sortable.query.filter().all()
    for i in range(len(final)):
    	# final_data = new_data[i].pref
    	# print("first:",final_data)
    	# final_data = final[i]
    	# print("second:",final_data)
    	new_data[i].pref = final[i]
    	db.session.commit()

    	
    return str("")



if __name__ == '__main__':
    app.run(debug=True)
